
export interface TradingSignal {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number; // 0-100
  ticker: string; // e.g., AAPL, BTC
  entryPrice: string;
  targetPrice: string;
  stopLoss: string;
  timeframe: string;
  reasoning: string;
  technicalIndicators: string[];
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

// Re-exporting for backward compatibility in state, though we will use TradingSignal mostly
export type AnalysisResult = TradingSignal & {
  timestamp: Date;
};
