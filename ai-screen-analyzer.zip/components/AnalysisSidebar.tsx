
import React, { useState, useEffect, useRef } from 'react';
import { AnalysisResult, ChatMessage } from '../types';
import { MessageSquare, Activity, Send, TrendingUp, TrendingDown, MinusCircle, ShieldAlert, Target, BarChart3 } from 'lucide-react';

interface AnalysisSidebarProps {
  isAnalyzing: boolean;
  analysisResult: AnalysisResult | null;
  chatHistory: ChatMessage[];
  onSendMessage: (msg: string) => void;
  isCapturing: boolean;
}

export const AnalysisSidebar: React.FC<AnalysisSidebarProps> = ({
  isAnalyzing,
  analysisResult,
  chatHistory,
  onSendMessage,
  isCapturing
}) => {
  const [activeTab, setActiveTab] = useState<'signals' | 'chat'>('signals');
  const [inputValue, setInputValue] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory, activeTab]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || !isCapturing) return;
    onSendMessage(inputValue);
    setInputValue('');
  };

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
      case 'SELL': return 'text-rose-400 bg-rose-400/10 border-rose-400/20';
      default: return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/20';
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 border-l border-slate-800">
      {/* Tabs */}
      <div className="flex items-center border-b border-slate-800">
        <button
          onClick={() => setActiveTab('signals')}
          className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
            activeTab === 'signals'
              ? 'text-indigo-400 border-b-2 border-indigo-500 bg-slate-900'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <Activity className="w-4 h-4" />
          Live Signals
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex-1 py-4 text-sm font-medium flex items-center justify-center gap-2 transition-colors ${
            activeTab === 'chat'
              ? 'text-indigo-400 border-b-2 border-indigo-500 bg-slate-900'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          Analyst Chat
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-4">
        {activeTab === 'signals' ? (
          <div className="space-y-6 animate-in fade-in duration-300">
            {isAnalyzing && !analysisResult && (
               <div className="flex flex-col items-center justify-center py-12 text-slate-500 gap-3">
                 <div className="relative">
                    <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                    <div className="absolute inset-0 flex items-center justify-center">
                        <BarChart3 className="w-5 h-5 text-indigo-500 animate-pulse" />
                    </div>
                 </div>
                 <p className="text-sm font-mono text-indigo-400">QUANTUM PROCESSING...</p>
               </div>
            )}

            {!isAnalyzing && !analysisResult && (
               <div className="flex flex-col items-center justify-center py-12 text-slate-500 gap-3 text-center">
                 <Activity className="w-12 h-12 opacity-50" />
                 <p className="text-sm">System Idle.<br/>Capture a chart to generate signals.</p>
               </div>
            )}

            {analysisResult && (
              <>
                {/* Signal Header Card */}
                <div className={`rounded-xl p-5 border ${getSignalColor(analysisResult.signal)} relative overflow-hidden`}>
                  <div className="absolute top-0 right-0 p-3 opacity-10">
                     {analysisResult.signal === 'BUY' ? <TrendingUp size={80} /> : analysisResult.signal === 'SELL' ? <TrendingDown size={80} /> : <MinusCircle size={80} />}
                  </div>
                  
                  <div className="flex justify-between items-start relative z-10">
                    <div>
                      <h2 className="text-xs font-bold uppercase tracking-wider opacity-70">Signal Detected</h2>
                      <div className="text-4xl font-black tracking-tighter mt-1">{analysisResult.signal}</div>
                      <div className="text-lg font-bold mt-1 text-slate-200">{analysisResult.ticker}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold uppercase tracking-wider opacity-70">Confidence</div>
                      <div className="text-3xl font-bold mt-1">{analysisResult.confidence}%</div>
                    </div>
                  </div>
                </div>

                {/* Price Levels Grid */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                    <div className="text-xs text-slate-500 uppercase mb-1">Entry</div>
                    <div className="font-mono font-medium text-indigo-300">{analysisResult.entryPrice}</div>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                    <div className="text-xs text-slate-500 uppercase mb-1">Target</div>
                    <div className="font-mono font-medium text-emerald-400">{analysisResult.targetPrice}</div>
                  </div>
                  <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-800">
                    <div className="text-xs text-slate-500 uppercase mb-1">Stop</div>
                    <div className="font-mono font-medium text-rose-400">{analysisResult.stopLoss}</div>
                  </div>
                </div>

                {/* Analysis Body */}
                <div className="bg-slate-900/50 rounded-xl p-4 border border-slate-800">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                    <Activity className="w-3 h-3" />
                    Technical Reasoning
                  </h3>
                  <p className="text-sm leading-relaxed text-slate-300 font-light">
                    {analysisResult.reasoning}
                  </p>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    {analysisResult.technicalIndicators.map((indicator, i) => (
                      <span key={i} className="px-2 py-1 rounded bg-slate-800 text-xs text-slate-400 border border-slate-700">
                        {indicator}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Risk Meter */}
                <div className="flex items-center justify-between bg-slate-900/30 p-3 rounded-lg border border-slate-800">
                   <span className="text-xs text-slate-500 uppercase">Risk Level</span>
                   <span className={`text-xs font-bold px-2 py-1 rounded ${
                     analysisResult.riskLevel === 'HIGH' ? 'bg-red-500/20 text-red-400' :
                     analysisResult.riskLevel === 'MEDIUM' ? 'bg-yellow-500/20 text-yellow-400' :
                     'bg-green-500/20 text-green-400'
                   }`}>
                     {analysisResult.riskLevel} RISK
                   </span>
                </div>

                <div className="text-[10px] text-slate-600 text-center pt-2 leading-tight">
                   Generated at {new Date(analysisResult.timestamp).toLocaleTimeString()}
                   <br/>
                   <span className="text-red-900/50">DISCLAIMER: Not financial advice. Use at own risk.</span>
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="flex flex-col h-full">
             <div className="flex-1 space-y-4 pb-4">
               {chatHistory.length === 0 && (
                  <div className="text-center py-12 text-slate-500">
                    <ShieldAlert className="w-8 h-8 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">QuantumFinance Analyst Ready.</p>
                    <p className="text-xs mt-2 text-slate-600">"Calculate Fibonacci levels for this trend."</p>
                    <p className="text-xs mt-1 text-slate-600">"What is the volume indicating?"</p>
                  </div>
               )}
               {chatHistory.map((msg, idx) => (
                 <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm ${
                     msg.role === 'user' 
                       ? 'bg-indigo-600 text-white rounded-br-sm' 
                       : 'bg-slate-800 text-slate-200 rounded-bl-sm border border-slate-700'
                   }`}>
                     {msg.text}
                   </div>
                 </div>
               ))}
               <div ref={chatEndRef} />
             </div>
             
             <form onSubmit={handleSend} className="relative mt-2">
               <input
                 type="text"
                 value={inputValue}
                 onChange={(e) => setInputValue(e.target.value)}
                 disabled={!isCapturing}
                 placeholder={isCapturing ? "Ask the analyst..." : "Start capture to chat"}
                 className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-4 pr-12 py-3 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed placeholder-slate-600 transition-all"
               />
               <button 
                 type="submit"
                 disabled={!inputValue.trim() || !isCapturing}
                 className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-indigo-500/10 hover:bg-indigo-500 text-indigo-500 hover:text-white rounded-lg transition-all disabled:opacity-0"
               >
                 <Send className="w-4 h-4" />
               </button>
             </form>
          </div>
        )}
      </div>
    </div>
  );
};
