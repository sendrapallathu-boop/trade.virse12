
import { GoogleGenAI, Type } from "@google/genai";
import { TradingSignal } from "../types";

// Initialize Gemini Client
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

const QUANTUM_FINANCE_PROMPT = `
You are QuantumFinance AI, an institutional-grade market intelligence system. 
Your goal is to analyze the financial data, stock charts, or market news visible on the screen to generate high-probability trading signals.

**Analysis Protocol:**
1. **Visual Scan**: Identify chart patterns (Head & Shoulders, Flags, Wedges), candlesticks (Doji, Hammer), and indicators (RSI, MACD, Bollinger Bands) visible in the image.
2. **Data Extraction**: Read any visible numbers, prices, or news headlines.
3. **Deep Reasoning**: Correlate the visual data with market principles. Calculate potential Risk/Reward ratios.
4. **Signal Generation**: precise entry, exit, and stop-loss points.

**Constraints:**
- While the user desires 100% accuracy, you must optimize for the *highest statistical probability* based on available data.
- If the screen does not show financial data, politely ask the user to show a chart or financial report.
`;

/**
 * Analyzes the provided screen frame (base64) and returns a structured trading signal.
 */
export const analyzeScreenContent = async (base64Image: string): Promise<TradingSignal> => {
  if (!apiKey) throw new Error("API Key not found");

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image
            }
          },
          {
            text: "Analyze this screen for trading opportunities. Provide a signal, entry, target, and deep technical reasoning."
          }
        ]
      },
      config: {
        systemInstruction: QUANTUM_FINANCE_PROMPT,
        // High thinking budget for deep technical analysis
        thinkingConfig: { thinkingBudget: 4096 }, 
        maxOutputTokens: 4096,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            signal: { type: Type.STRING, enum: ["BUY", "SELL", "HOLD"] },
            confidence: { type: Type.NUMBER, description: "Confidence score between 0 and 100" },
            ticker: { type: Type.STRING, description: "The detected asset symbol (e.g. AAPL, BTC, EURUSD)" },
            entryPrice: { type: Type.STRING, description: "Recommended entry price range" },
            targetPrice: { type: Type.STRING, description: "Take profit level" },
            stopLoss: { type: Type.STRING, description: "Stop loss level" },
            timeframe: { type: Type.STRING, description: "Estimated timeframe (e.g. Intraday, Swing, Long-term)" },
            reasoning: { type: Type.STRING, description: "Concise paragraph explaining the technical/fundamental basis." },
            technicalIndicators: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "List of detected indicators (e.g., 'RSI Divergence', 'Golden Cross')" 
            },
            riskLevel: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH"] }
          },
          required: ["signal", "confidence", "ticker", "entryPrice", "targetPrice", "stopLoss", "reasoning", "technicalIndicators", "riskLevel"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as TradingSignal;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    // Fallback structure
    return {
      signal: 'HOLD',
      confidence: 0,
      ticker: 'UNKNOWN',
      entryPrice: '-',
      targetPrice: '-',
      stopLoss: '-',
      timeframe: '-',
      reasoning: "Unable to analyze market data. Please ensure a clear chart is visible.",
      technicalIndicators: ["Connection Error"],
      riskLevel: 'HIGH'
    };
  }
};

/**
 * Sends a user question along with the current screen frame to Gemini.
 */
export const askQuestionAboutScreen = async (base64Image: string, question: string): Promise<string> => {
  if (!apiKey) throw new Error("API Key not found");

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image
            }
          },
          {
            text: `Question: ${question}\n\nPerform a deep financial analysis to answer.`
          }
        ]
      },
      config: {
        thinkingConfig: { thinkingBudget: 2048 },
        maxOutputTokens: 8192,
        systemInstruction: QUANTUM_FINANCE_PROMPT
      }
    });

    return response.text || "I couldn't generate a financial insight.";

  } catch (error) {
    console.error("Gemini Chat Error:", error);
    return "Market data analysis interrupted. Please try again.";
  }
};
